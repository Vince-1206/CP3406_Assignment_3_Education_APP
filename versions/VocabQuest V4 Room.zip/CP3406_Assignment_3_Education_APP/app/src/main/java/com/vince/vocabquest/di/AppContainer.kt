package com.vince.vocabquest.di

import android.content.Context
import com.vince.vocabquest.data.OfflineProgressRepository
import com.vince.vocabquest.data.ProgressRepository
import com.vince.vocabquest.data.SampleVocabularyRepository
import com.vince.vocabquest.data.VocabularyRepository
import com.vince.vocabquest.data.local.VocabQuestDatabase

interface AppContainer {
    val vocabularyRepository: VocabularyRepository
    val progressRepository: ProgressRepository
}

class DefaultAppContainer(context: Context) : AppContainer {
    private val database by lazy {
        VocabQuestDatabase.getDatabase(context)
    }

    override val vocabularyRepository: VocabularyRepository by lazy {
        SampleVocabularyRepository()
    }

    override val progressRepository: ProgressRepository by lazy {
        OfflineProgressRepository(database.quizResultDao())
    }
}
