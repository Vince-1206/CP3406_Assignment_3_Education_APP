package com.vince.vocabquest.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

const val LEARNING_ROUTE = "learning"

enum class VocabQuestDestination(
    val route: String,
    val label: String,
    val icon: ImageVector,
) {
    Home(route = "home", label = "Home", icon = Icons.Default.Home),
    Activity(route = "activity", label = "Quiz", icon = Icons.Default.Quiz),
    Statistics(route = "statistics", label = "Progress", icon = Icons.Default.BarChart),
    Settings(route = "settings", label = "Settings", icon = Icons.Default.Settings),
}
