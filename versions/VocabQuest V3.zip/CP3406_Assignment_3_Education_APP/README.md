# VocabQuest

VocabQuest is a vocabulary-learning Android app for secondary-school ESL students aged 12–18. It combines short study cards with multiple-choice quizzes and clear progress feedback.

This repository contains Han-Wei Lin's CP3406 Assessment 3 project.

## Current milestone

Milestone 3 connects the learning and quiz experience on top of the Compose foundation:

- Kotlin and Jetpack Compose
- Material Design 3 interface
- Four required assignment screens: Landing, Activity, Settings, and User Statistics
- Separate Learn Vocabulary screen so definitions are studied before the quiz
- Ten secondary-school ESL vocabulary items in the starter lesson
- Quiz questions that keep definitions hidden until an answer is submitted
- Quiz results with explicit Home, Progress, and Try Again actions
- Connected Home → Learn 10 words → Quiz 10 questions → Results lesson flow
- Navigation Component with Home, Progress, and Settings in the persistent bottom bar
- Quiz is reached through the lesson instead of bypassing learning from the bottom bar
- ViewModel and Repository separation
- Simple dependency container
- Sample vocabulary repository and quiz logic
- Non-GUI model tests and a starter Compose UI test
- Accessibility-minded controls and privacy-by-design explanations

Statistics are sample values in this milestone. Networking and persistent Room data will be implemented in later milestones.

## Planned features

1. Fetch word definitions from a relevant external dictionary API.
2. Store quiz results, settings, and teacher-created questions with Room.
3. Add a simple local quiz creator without requiring student accounts.
4. Replace sample statistics with calculated learning progress.
5. Expand model and Compose UI testing.
6. Add responsive layouts, loading states, and network error handling.

## App structure

```text
app/src/main/java/com/vince/vocabquest/
├── data/          Repository interface and data implementations
├── di/            Application dependency container
├── model/         Vocabulary and quiz models
└── ui/
    ├── navigation/
    ├── screens/
    └── theme/
```

## Run the project

1. Clone or download this repository.
2. Open the project folder in Android Studio.
3. Allow Gradle Sync to finish.
4. Select an Android emulator or connected device using API 26 or later.
5. Click **Run app**.

The project uses Java 17, Android Gradle Plugin 8.13.2, compile SDK 36, and the stable Compose BOM.

## Ethical design direction

- No account, name, email, or location is required.
- Progress is intended to remain on the learner's device.
- The interface uses readable typography, labelled navigation, large controls, and reduced-motion settings.
- Content is designed to be appropriate for secondary-school learners.
- Feedback supports learning without public rankings or manipulative streak pressure.

## Assignment status

- [x] App concept and target audience
- [x] Compose project foundation
- [x] Four core screens
- [x] Navigation foundation
- [x] Connected Learn → Quiz lesson experience
- [x] Ten-word starter vocabulary lesson
- [x] Starter ViewModel and Repository architecture
- [x] Starter unit and GUI tests
- [ ] External API integration
- [ ] Room database
- [ ] Persistent settings and statistics
- [ ] Teacher quiz creator
- [ ] Final testing and UI polish
- [ ] 1000-word Gibbs' Reflective Cycle self-reflection
- [ ] Declaration of AI-Generated Material
