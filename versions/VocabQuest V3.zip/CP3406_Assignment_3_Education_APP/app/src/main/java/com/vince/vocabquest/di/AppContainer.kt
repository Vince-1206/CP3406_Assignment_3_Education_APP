package com.vince.vocabquest.di

import com.vince.vocabquest.data.SampleVocabularyRepository
import com.vince.vocabquest.data.VocabularyRepository

interface AppContainer {
    val vocabularyRepository: VocabularyRepository
}

class DefaultAppContainer : AppContainer {
    override val vocabularyRepository: VocabularyRepository by lazy {
        SampleVocabularyRepository()
    }
}
