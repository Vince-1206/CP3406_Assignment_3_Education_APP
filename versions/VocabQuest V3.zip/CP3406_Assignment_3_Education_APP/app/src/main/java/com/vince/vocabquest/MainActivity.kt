package com.vince.vocabquest

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.vince.vocabquest.ui.VocabQuestApp
import com.vince.vocabquest.ui.theme.VocabQuestTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val repository = (application as VocabQuestApplication).container.vocabularyRepository

        setContent {
            VocabQuestTheme {
                VocabQuestApp(vocabularyRepository = repository)
            }
        }
    }
}
