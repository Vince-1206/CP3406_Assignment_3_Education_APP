package com.vince.vocabquest.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.vince.vocabquest.data.VocabularyRepository
import com.vince.vocabquest.model.VocabularyQuestion
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class LearningUiState(
    val words: List<VocabularyQuestion> = emptyList(),
    val currentIndex: Int = 0,
) {
    val currentWord: VocabularyQuestion?
        get() = words.getOrNull(currentIndex)

    val isFirstWord: Boolean
        get() = currentIndex == 0

    val isLastWord: Boolean
        get() = words.isNotEmpty() && currentIndex == words.lastIndex
}

class LearningViewModel(
    repository: VocabularyRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(
        LearningUiState(words = repository.getStarterQuestions()),
    )
    val uiState: StateFlow<LearningUiState> = _uiState.asStateFlow()

    fun previousWord() {
        _uiState.update { state ->
            state.copy(currentIndex = (state.currentIndex - 1).coerceAtLeast(0))
        }
    }

    fun nextWord() {
        _uiState.update { state ->
            if (state.words.isEmpty()) {
                state
            } else {
                state.copy(currentIndex = (state.currentIndex + 1).coerceAtMost(state.words.lastIndex))
            }
        }
    }

    class Factory(
        private val repository: VocabularyRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(LearningViewModel::class.java)) {
                return LearningViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
